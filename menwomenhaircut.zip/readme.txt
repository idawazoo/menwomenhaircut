272 pics original from google images

split between men and women

sample
- train - 8 images
- valid - 4 images
train - 60% of (272 - 8 - 4) = 156
valid - 20% of (272 - 8 - 4) = 52
test1 - 20% of (272 - 8 - 4) = 52
